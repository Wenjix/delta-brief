"""Simple chatbot example for MemMachine."""
