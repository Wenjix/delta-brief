"Evaluation utilities for the locomo episodic agent."
