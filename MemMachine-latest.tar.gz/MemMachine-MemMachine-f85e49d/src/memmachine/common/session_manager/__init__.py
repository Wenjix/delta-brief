"""Session manager utilities for MemMachine."""
