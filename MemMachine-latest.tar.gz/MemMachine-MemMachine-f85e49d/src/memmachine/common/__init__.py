"""Common utilities and shared abstractions for MemMachine."""
