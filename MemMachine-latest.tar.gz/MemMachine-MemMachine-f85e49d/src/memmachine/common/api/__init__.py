"""Shared API definitions for MemMachine client and server."""
