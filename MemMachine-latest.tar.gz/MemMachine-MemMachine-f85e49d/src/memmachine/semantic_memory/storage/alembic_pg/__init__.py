"""Alembic migrations for the semantic memory PostgreSQL backend."""
