"""Storage backends for semantic memory."""
