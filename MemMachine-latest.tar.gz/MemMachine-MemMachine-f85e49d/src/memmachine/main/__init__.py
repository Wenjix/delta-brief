"""Main MemMachine entrypoints and configuration utilities."""
