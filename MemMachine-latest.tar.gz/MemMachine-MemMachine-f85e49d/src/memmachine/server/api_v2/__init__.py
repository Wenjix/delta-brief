"""API v2 endpoints for MemMachine server."""
