"""Prompt templates for MemMachine server tools."""
