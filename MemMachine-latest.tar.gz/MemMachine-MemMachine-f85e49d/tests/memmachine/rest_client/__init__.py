"""Unit tests for the MemMachine REST client."""
